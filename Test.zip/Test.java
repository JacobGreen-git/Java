public class Test {
    public static void main(String[] args) {
        String name = "Coding Dojo";
        int age = 100;
        String location = "Burbank, CA";
        System.out.println("My name is " + name +"." + "\n" + " I am " + age + " years old." + "\n" + "My hometown is " + location + ".");
    }
}
